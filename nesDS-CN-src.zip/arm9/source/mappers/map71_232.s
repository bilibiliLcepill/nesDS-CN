;@----------------------------------------------------------------------------
	#include "equates.h"
;@----------------------------------------------------------------------------
	.global mapper71init
	.global mapper232init

	.struct mapperData
mapbyte1:	.byte 0
mapbyte2:	.byte 0
;@----------------------------------------------------------------------------
.section .text,"ax"
;@----------------------------------------------------------------------------
;@ Camerica/Codemasters mapper
;@ Used in:
;@ MiG 29 - Soviet Fighter
;@ Fire Hawk
;@ The Fantastic Adventures of Dizzy
;@ Bee 52
mapper71init:
;@----------------------------------------------------------------------------
	.word map71w,rom_W,map89AB_,map89AB_
	bx lr
;@----------------------------------------------------------------------------
;@ Camerica/Codemasters mapper
;@ Used in:
;@ Quattro Adventure
;@ Quattro Sports
;@ Quattro Arcade
mapper232init:
;@----------------------------------------------------------------------------
	.word write0,write0,write1,write1
	mov r0,#0x18
	strb_ r0,mapbyte1
	bx lr
;@----------------------------------------------------------------------------
map71w:
	tst addy,#0x1000
	bxeq lr
	tst r0,#0x10
	b mirror1_
;@----------------------------------------------------------------------------
write0:
;@----------------------------------------------------------------------------
	and r0,r0,#0x18
	strb_ r0,mapbyte1
	b prgMap
;@----------------------------------------------------------------------------
write1:
;@----------------------------------------------------------------------------
	and r0,r0,#0x03
	strb_ r0,mapbyte2
	ldrb_ r0,mapbyte1
prgMap:
	stmfd sp!, {lr}
	mov r1,#3
	orr r0,r1,r0,lsr#1
	bl mapCDEF_

	ldrb_ r0,mapbyte1
	ldrb_ r1,mapbyte2
	orr r0,r1,r0,lsr#1
	ldmfd sp!, {lr}
	b map89AB_
;@----------------------------------------------------------------------------
