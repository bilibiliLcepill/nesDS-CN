;@----------------------------------------------------------------------------
	#include "equates.h"
;@----------------------------------------------------------------------------
	.global mapper15init

	.struct mapperData
waste:		.word 0
;@----------------------------------------------------------------------------
.section .text,"ax"
;@----------------------------------------------------------------------------
;@ K-1029 and K-1030P boards
;@ Used in:
;@ 100-in-1 Contra Function 16
;@ 168-in-1 New Contra Function 16
mapper15init:
;@----------------------------------------------------------------------------
	.word write800x,rom_W,rom_W,rom_W

	mov r0,#0
	b map89ABCDEF_
;@----------------------------------------------------------------------------
write800x:
;@----------------------------------------------------------------------------
	bic addy,addy,#0x8000
	cmp addy,#3
	bxhi lr
	bne w80
w83:
	str_ r0,waste
	mov addy,lr
	tst r0,#0x40
	bl mirror2V_
	ldr_ r0,waste
	tst r0,#0x80
	beq swap1_16

	mov r0,r0,lsl#1
	str_ r0,waste
	add r0,r0,#1
	bl mapCD_
	mov lr,addy
	ldr_ r0,waste
	b mapEF_
swap1_16:
	mov lr,addy
	b mapCDEF_
w80:
	cmp addy,#0
	bne w81
	mov addy,lr
	str_ r0,waste
	tst r0,#0x40
	bl mirror2V_
	ldr_ r0,waste
	tst r0,#0x80
	beq swap2_16

	mov r0,r0,lsl#1
	str_ r0,waste
	add r0,r0,#1
	bl map89_
	ldr_ r0,waste
	bl mapAB_
	ldr_ r0,waste
	add r0,r0,#2
	bl mapCD_
	mov lr,addy
	ldr_ r0,waste
	add r0,r0,#1
	b mapEF_
swap2_16:
	bl map89AB_
	mov lr,addy
	ldr_ r0,waste
	add r0,r0,#1
	b mapCDEF_
w81:
	cmp addy,#1
	bne w82
	mov addy,lr
	bl map89AB_
	movs r0,#0			;@ This sets the Z flag.
	bl mirror2V_
	mov r0,#-1
	mov lr,addy
	b mapCDEF_
w82:
	cmp addy,#2
	bxne lr

	mov addy,lr
	mov r0,r0,lsl#1
	add r0,r0,r0,lsr#8
	str_ r0,waste

	bl map89_
	ldr_ r0,waste
	bl mapAB_
	ldr_ r0,waste
	bl mapCD_
	mov lr,addy
	ldr_ r0,waste
	b mapEF_
;@----------------------------------------------------------------------------
