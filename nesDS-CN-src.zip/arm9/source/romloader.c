#include <nds.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <stdlib.h>
#include <unistd.h>
#include "c_defs.h"
#include "minIni.h"
#include "menu.h"
#include "NesMachine.h"
//#include "extlink_filestruct.h"

extern int subscreen_stat;
extern int shortcuts_tbl[16];

char tmpname[] = "dszip.tmp";

char diskbios[8192];
const int diskbios_size = sizeof(diskbios);

int romsize;	//actual rom size
int freemem_start;	//points to unused mem (end of loaded rom)
int freemem_end;
u32 oldinput;

char romfilename[256];	//name of current rom.  null when there's no file (rom was embedded)
char *romfileext;	//points to file extension

//extern u8 autostate;			//from ui.c
int active_interface = 0;

void rommenu(int roms);
void drawmenu(int sel,int roms);
extern void cjk_prepare(void);
int getinput(void);

int init_rommenu(void);
void listrom(int line,int rom,int highlight); //print rom title
int loadrom();	//return -1 on success
int selectrom(int rom);	//return -1 on success, or rom count (from directory change)
void stringsort(char**);

char *adjust_fds(const char *name, char *rom, int romSize)
{
	char *newPtr = rom;
	if (strstr(name, ".FDS") || strstr(name, ".fds")) {
		int discCount = 0;
		if (romSize == 65500) {
			discCount = 1;
		}
		else if (romSize == 65500 * 2) {
			discCount = 2;
		}
		else if (romSize == 65500 * 4) {
			discCount = 4;
		}
		if (discCount != 0) {
			newPtr -= 16;
			newPtr[0] = 'F';
			newPtr[1] = 'D';
			newPtr[2] = 'S';
			newPtr[4] = discCount;
		}
	}
	return newPtr;
}

int is_nsf_file(const char *name, char *rom)
{
	// actually the first four chars should be "NESM"
	if (strstr(name, ".NSF") || strstr(name, ".nsf")) {
		memcpy(&nsfHeader, rom, sizeof(nsfHeader));
		__emuflags |= NSFFILE;
		__nsfSongNo = 0;
		__nsfPlay = 0;
		__nsfInit = 0;
		IPC_MAPPER = 256;
		return 1;
	}
	__emuflags &= ~NSFFILE;
	return 0;
}

/*****************************
* name:			do_rommenu
* function:		show a menu to select a nes rom file.
* argument:		none
* description:		called when starting.
******************************/
int global_roms = 0;

void do_rommenu() {
	int roms = global_roms;

	ips_stat = false;		//disable ips first.

	fifoSendValue32(FIFO_USER_08, FIFO_APU_PAUSE);			//disable sound when selecting a rom.

	if (!global_roms) {
		roms=init_rommenu();
		global_roms = roms;
	}

	if (!roms) {
		if (!active_interface) {			//another driver is present, but init failed
			consoletext(64*3,"Device failed.",0);
		} else {						//no DLDI error, no files
			consoletext(64*3,"No roms found.",0);
		}
		while(1) swiWaitForVBlank();
	}
	showconsole();
	clearconsole();
	showversion();
	rommenu(global_roms);
	menu_stat = 0;
	menu_draw = 0;
	hideconsole();
	clearconsole();
}

/*****************************
* name:			rommenu
* function:		show a rom menu.
* argument:		roms: the count of valid roms.
* description:		called by do_rommenu.
******************************/
void rommenu(int roms) {
	static int selectedrom = 0;
	int key;
	int sel = selectedrom;
	int loaded = 0;

	if (romfilename[0] != '\0')
		save_sram();

	oldinput=IPC_KEYS;

	if (roms == 1)
		key = KEY_START;
	else
		key = 0x80000000;
	do {
		swiWaitForVBlank();
		switch(key) {
			case KEY_START:
			case KEY_B:
			case KEY_A:
			case KEY_Y:
				loaded = selectrom(sel);
				if (loaded > 0) {	//didn't load (it was a directory) loaded == 0 means that ips file is loaded.
					sel = 0;
					roms = loaded;
					global_roms = roms;
				}
				break;
			case KEY_RIGHT:
				sel += 10;
				if (sel > roms-1) sel = roms-1;
				break;
			case KEY_LEFT:
				sel -= 10;
				if (sel < 0) sel = 0;
				break;
			case KEY_UP:
				sel = sel+roms-1;
				break;
			case KEY_DOWN:
				sel++;
				break;
		}
		sel %= roms;
		if (key && loaded >= 0)
			drawmenu(sel,roms);
		key = getinput();
	} while (loaded >= 0);

	selectedrom = sel;
}

#define ROWS 11
#define OFFSET 0
/*****************************
* name:			drawmenu
* function:		show a rom menu.
* argument:		sel: the select number
			roms: count of roms
* description:		called by rommenu.
******************************/
void drawmenu(int sel,int roms) {
	int i,j,topline,rom;
	
	clearconsole();
	cjk_prepare();						/* reset CJK tile slots for this menu */
				if(roms>ROWS) {
		/* window follows selection: 1 keypress = 1 item = 2 screen rows */
		rom = sel - (ROWS / 2);
		if (rom < 0) rom = 0;
		if (rom + ROWS > roms) rom = roms - ROWS;
		j = ROWS;
	} else {
		rom = 0;
		j = roms;
	}
	REG_BG0VOFS_SUB = 0;	/* static rows; window redraw per keypress */

	for(i=0;i<j;i++) {
		/* each item spans 2 screen rows: CJK 16x16 glyph = row L and L+1 */
		listrom(OFFSET + i*2, rom, sel==rom);
		rom++;
	}
	{	/* v17: failed codepoint U= + raw bytes R= on row 22; row 23 shows second failure */
		extern unsigned int cjk_db_bad[8]; extern unsigned char cjk_db_raw[8][6];
		extern int cjk_db_gbk[8]; extern int cjk_db_nbad;
		extern int cjk_db_slot, cjk_db_row, cjk_db_lim;
		static const char hex[] = "0123456789ABCDEF";
		char db[36];
		int L, k, b;

		/* row 22: F=xx s=xx r=xx l=xx U=xxxx R=xxxxxx (first failure) */
		L = 0;
		db[L++]='F'; db[L++]='=';
		db[L++]=hex[(cjk_db_nbad>>4)&15]; db[L++]=hex[cjk_db_nbad&15];
		db[L++]=' '; db[L++]='s'; db[L++]='=';
		db[L++]=hex[(cjk_db_slot>>4)&15]; db[L++]=hex[cjk_db_slot&15];
		db[L++]=' '; db[L++]='r'; db[L++]='=';
		db[L++]=hex[(cjk_db_row>>4)&15]; db[L++]=hex[cjk_db_row&15];
		db[L++]=' '; db[L++]='l'; db[L++]='=';
		db[L++]=hex[(cjk_db_lim>>4)&15]; db[L++]=hex[cjk_db_lim&15];
		if (cjk_db_nbad > 0) {
			db[L++]=' '; db[L++]='U'; db[L++]='=';
			db[L++]=hex[(cjk_db_bad[0]>>12)&15]; db[L++]=hex[(cjk_db_bad[0]>>8)&15];
			db[L++]=hex[(cjk_db_bad[0]>>4)&15]; db[L++]=hex[cjk_db_bad[0]&15];
			db[L++]=' '; db[L++]='R'; db[L++]='=';
			for (b = 0; b < 6; b++) { db[L++]=hex[cjk_db_raw[0][b]>>4]; db[L++]=hex[cjk_db_raw[0][b]&15]; }
		}
		db[L] = 0;
		menutext(22, db, 0);

		/* row 23: U=xxxx R=xxxxxx (second failure) or blank */
		L = 0;
		if (cjk_db_nbad > 1) {
			db[L++]='U'; db[L++]='=';
			db[L++]=hex[(cjk_db_bad[1]>>12)&15]; db[L++]=hex[(cjk_db_bad[1]>>8)&15];
			db[L++]=hex[(cjk_db_bad[1]>>4)&15]; db[L++]=hex[cjk_db_bad[1]&15];
			db[L++]=' '; db[L++]='R'; db[L++]='=';
			for (b = 0; b < 6; b++) { db[L++]=hex[cjk_db_raw[1][b]>>4]; db[L++]=hex[cjk_db_raw[1][b]&15]; }
		}
		db[L] = 0;
		menutext(23, db, 0);
	}
}

/*****************************
* name:			getinput
* function:		get a key input for rom selection.
* argument:		none
* description:		called by rommenu.
******************************/
int getinput() {
	static int lastdpad,repeatcount=0;
	int dpad;
	int keyhit;
	scanKeys();
	IPC_KEYS = keysCurrent();
	keyhit=(oldinput^IPC_KEYS)&IPC_KEYS;
	oldinput=IPC_KEYS;
	dpad=IPC_KEYS&(KEY_UP+KEY_DOWN+KEY_LEFT+KEY_RIGHT);
	if(lastdpad==dpad) {
		repeatcount++;
		if(repeatcount<25 || repeatcount&3)	//delay/repeat
			dpad=0;
	} else {
		repeatcount=0;
		lastdpad=dpad;
	}
	return dpad|(keyhit&(KEY_Y+KEY_X+KEY_A+KEY_B+KEY_START));
}

/*****************************
* name:			listrom
* function:		show a rom file name on the sub-screen.
* argument:		line: row number on the screnn.
			rom: rom number of the roms list.
			highlight: if the rom is selected(highlighted).
* description:		called by rommenu.
******************************/
void listrom(int line,int rom,int highlight) {
	char *s;
	char **files=(char**)rom_files;
	s=files[rom];
	if(*s==1) {	//dir
		menutext(line,s+1,highlight?2:0);
	} else		//file
		menutext(line,s+1,highlight);
}

/*****************************
* name:         loadrom
* function:		load a rom to memory, for NES emulation.
* description:	called by selectrom and bootext
*****************************/
int loadrom() {
	FILE *f; // rom file
	int i; // romsize
	char *roms; // rom data

	if (strstr(romfilename, ".fds") || strstr(romfilename, ".FDS")) {
		if ((__emuflags & DISKBIOS) == 0) {
			return 1;
		}
	}

	if (strstr(romfilename, ".GZ") || strstr(romfilename, ".gz") ||
		strstr(romfilename, ".ZIP") || strstr(romfilename, ".zip")
	) {	// a gz file is loaded.
		if (load_gz(romfilename)) {
			return 1;	//fail to unzip.
		}
		f = fopen(tmpname,"r");
	}
	else {
		f = fopen(romfilename,"r");
	}

	romfileext = strrchr(romfilename,'.')+1;
	roms = (char *)rom_start;
	i = fread(roms,1,ROM_MAX_SIZE,f);	//read the whole thing (filesize=some huge number, don't care)
	do_ips(i);

	fclose(f);

	if (strstr(romfilename, ".GZ") || strstr(romfilename, ".gz") ||
		strstr(romfilename, ".ZIP") || strstr(romfilename, ".zip")
		) {    // a gz file is loaded.
		unlink(tmpname);
	}
	romsize = i;
    if (i < 0x100000)
        i = 0x100000;            // leave some room for FDS files. Also the NSF file need some extra memory
    freemem_start = ((u32)roms+i+3)&~3;
    freemem_end = (u32)roms+ROM_MAX_SIZE;

	if (!is_nsf_file(romfilename, roms)) {
		roms = adjust_fds(romfilename, roms, romsize);
		romcorrect(roms);
	}
	initcart(roms);
	IPC_MAPPER = debuginfo[MAPPER];

	load_sram();
	//if(autostate) loadstate(..);

	return -1;	//(-1 on success)
}

/*****************************
* name:			selectrom
* function:		enter a subdir or select a rom.
* argument:		rom: rom number of the roms list.
* description:		called by rommenu.
******************************/
int selectrom(int rom) {
	char **files=(char**)rom_files;

	if (*files[rom] == 1) {	// directory
		chdir(files[rom]+1);
		return init_rommenu();
	} else {	//file
		if (strstr(files[rom]+1, ".ips") || strstr(files[rom]+1, ".IPS")) {	// a ips file is loaded.
			load_ips(files[rom]+1);
			return 0;
		}
		else {
			memcpy(romfilename,files[rom]+1,256);

			return loadrom();
		}
	}
}

/*****************************
* name:			init_rommenu
* function:		count the nes roms&dirs in current dir...
* argument:		none
* description:		called by do_rommenu.
******************************/
// return number of file entries (roms+dirs)
int init_rommenu() {
	char **files;
	char *nextfile;
	int idx=0;
	DIR *dir = NULL;
	struct dirent *cnt = NULL;
	struct stat statbuf;

	if(!active_interface) {		//DLDI trouble
		return 0;
	}
	files = (char**)rom_files;
	nextfile=(char*)&files[MAXFILES];
	dir=opendir(".");			//chdir to root
	cnt=readdir(dir);
	stat(cnt->d_name,&statbuf);

	while(cnt != NULL && (idx<MAXFILES - 1) && dir != NULL) {
		if(((strstr(cnt->d_name, ".NES") || strstr(cnt->d_name, ".nes")) 
			|| (strstr(cnt->d_name, ".FDS") || strstr(cnt->d_name, ".fds"))
			|| (strstr(cnt->d_name, ".IPS") || strstr(cnt->d_name, ".ips"))
			|| (strstr(cnt->d_name, ".GZ") || strstr(cnt->d_name, ".gz"))
			|| (strstr(cnt->d_name, ".ZIP") || strstr(cnt->d_name, ".zip"))
			|| (strstr(cnt->d_name, ".nsf") || strstr(cnt->d_name, ".nsf"))
			|| (S_ISDIR(statbuf.st_mode)) 
			|| strcmp("..", cnt->d_name) == 0) && strcmp(".", cnt->d_name) != 0) {
			if(S_ISDIR(statbuf.st_mode) || strcmp("..", cnt->d_name) == 0)
				*nextfile = 1;
			else 
				*nextfile = 2;
			strcpy(nextfile + 1, cnt->d_name);
			files[idx]=nextfile;
			nextfile+=strlen(nextfile)+1;
			idx++;
		}
		cnt=readdir(dir);
		stat(cnt->d_name,&statbuf);
	}
	files[idx]=0;
	stringsort(files);
	if(dir)
		closedir(dir);
	return idx;
}


/*****************************
* name:			less
* function:		return (s1 < s2)
* argument:		s1, s2
* description:		cmpare to strings.for sorting.
******************************/
// case insensitive string compare
inline int less(char *s1,char *s2) {
	int c1,c2;
	do {
		c1=*s1++;
		c2=*s2++;
		if(c1>='a') c1=c1-'a'+'A';
		if(c2>='a') c2=c2-'a'+'A';
	} while(c1==c2);
	return c1<c2;
}

/*****************************
* name:			stringsort
* function:		sort the strings.
* argument:		p1: pointer of string list.
* description:		none
******************************/
// lazy man's string sorter
void stringsort(char **p1) {
	char **p2;
	char *s1,*s2;
	do {	//next s1
		s1 = *p1;
		if (s1) {
			p2 = p1;
			do {	//next s2
				p2++;
				s2 = *p2;
				if (s2 && less(s2,s1)) {
					*p1 = s2;
					*p2 = s1;
					s1 = s2;
				}
			} while(s2);
		}
		p1++;
	} while(s1);
}

extern int argc;
extern char **argv;
char inibuf[768];
char disksyspath[768];
char ininame[768];
char defaultDisksyspath[] = "/disksys.rom";

char *findpath(int argc, char **argv, const char *name){
	int i=0;
	for (;i<argc;i++){
		strcpy(ininame,argv[i]);
		if (ininame[strlen(ininame)-1]!='/')strcat(ininame,"/");
		strcat(ininame,name);
		if (!access(ininame,0))return ininame;
	}
	// create at root on next save
	ininame[0]='/';
	strcpy(&ininame[0]+1,name);
	return NULL;
}

char none[] = " ";

int keystr2int(char *buf)
{
	int i;
	int ret = 0;
	if (buf[0] == 0) return 0;
	for (i = 0; i < 12; i++) {
		if (strstr(buf, keystrs[i]) != NULL) {
			ret |= (1 << i);
		}
	}
	return ret;
}

int bootext() {
	//interrupt 0: set my dir (inibuf)
	int i;
	strcpy(inibuf,"/");
	if (argc>0){
		strcpy(inibuf,argv[0]);
		i = strlen(inibuf)+1;
		for (;i>0;i--) if (inibuf[i-1] == '/') {inibuf[i] = 0;break;}
	}

	memset(shortcuts_tbl, 0, sizeof(shortcuts_tbl));
	if (findpath(8,(char*[]){"/","/_dstwoplug/","/ismartplug/","/moonshl2/extlink/","/_iMenu/_ini/","/_plugin_/","/_nds/",inibuf},"nesDS.ini")){
		//interrupt 1: read config
		int iniret;
		if ((iniret=ini_getl("nesDSrev2","BASwap",0,ininame)) != 0) joyflags|=B_A_SWAP;

		if ((iniret=ini_getl("nesDSrev2","LRDisable",0,ininame)) != 0) joyflags|=L_R_DISABLE;
		if ((iniret=ini_getl("nesDSrev2","Blend",0,ininame)) != 0) __emuflags|=iniret&3;
		if ((iniret=ini_getl("nesDSrev2","PALTiming",0,ininame)) != 0) __emuflags|=PALTIMING;
		if ((iniret=ini_getl("nesDSrev2","FollowMem",0,ininame)) != 0) __emuflags|=FOLLOWMEM;
		if ((iniret=ini_getl("nesDSrev2","ScreenSwap",0,ininame)) != 0) __emuflags|=SCREENSWAP;
		if ((iniret=ini_getl("nesDSrev2","AllPixelOn",0,ininame)) != 0) __emuflags|=ALLPIXELON;
		if ((iniret=ini_getl("nesDSrev2","Render",0,ininame)) != 0)  {
			if (iniret == 1)	__emuflags|=SPLINE;
			else __emuflags|=SOFTRENDER;
		}
		if ((iniret=ini_getl("nesDSrev2","AutoSRAM",0,ininame)) != 0) __emuflags|=AUTOSRAM;
		if ((iniret=ini_getl("nesDSrev2","Screen_Scale",0,ininame)) != 0) ad_scale=iniret;
		if ((iniret=ini_getl("nesDSrev2","Screen_Offset",0,ininame)) != 0) ad_ypos=iniret;
		if ((iniret=ini_getl("nesDSrev2","Screen_Gamma",0,ininame)) != 0) gammavalue=iniret;
		if ((iniret=ini_getl("nesDSrev2","Screen_Palette",0,ininame)) != 0) palette_value=iniret;
		palset();
		if ((iniret=ini_getl("nesDSrev2","AutoFire",2,ininame)) != 0) autofire_fps=iniret;
		if ((iniret=ini_getl("nesDSrev2","UseSavesDir",0,ininame)) != 0) use_saves_dir=true;
		__af_start = ((autofire_fps >> 1) << 8) + (autofire_fps >> 1) + (autofire_fps & 1);

		rescale(ad_scale, ad_ypos);

		for (i = 0 ; i < MAX_SC; i++) {
			if ((iniret=ini_getl("nesDSrev2",ishortcuts[i],0,ininame)) != 0) shortcuts_tbl[i]=iniret;
			else {
				ini_gets("nesDSrev2", ishortcuts[i], none, inibuf, 512, ininame);
				shortcuts_tbl[i] = keystr2int(inibuf);
			}

			ini_gets("nesDSrev2", igestures[i], none, gestures_tbl[i], 24, ininame);
		}

		ini_gets("nesDSrev2","StartIn","/",inibuf,768,ininame);
		ini_gets("nesDSrev2","DisksysBios",defaultDisksyspath,disksyspath,768,ininame);
	}
	/*else{
		strcpy(inibuf,"/");
	}*/

	if (!*inibuf||inibuf[strlen(inibuf)-1]!='/')strcat(inibuf,"/");
	chdir(inibuf); //might be overwritten in readFrontend()

	// if we didn't have an ini, this'll be blank
	if (disksyspath[0] == 0) {
		strcpy(disksyspath, defaultDisksyspath);
	}
	FILE *bios = fopen(disksyspath, "r");
	if (bios != NULL) {
		fseek(bios, 0, SEEK_END);
		size_t offset = ftell(bios);
		if (offset < 8193) { // FDS BIOS should be 8KB, we'll accept anything that fits in our buffer
			fseek(bios, 0, SEEK_SET);
			fread(diskbios, 8192, 1, bios);

			__emuflags |= DISKBIOS;
		}
		fclose(bios);
	}

	// interrupt 2: read frontend
	if (!readFrontend(romfilename)) return 0;

	// interrupt 3: load rom
	if (loadrom() == -1) return 1;
	return 0;
}

int load_gz(const char *fname)
{
#if 1
	int ret;
	ret = do_decompression(fname, tmpname);
	return ret;
#endif
	return 0;
}
