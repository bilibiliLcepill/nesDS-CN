#include <nds.h>
#include "c_defs.h"
#include "NesMachine.h"
#include "cjkfont.h"

extern u16 font;
extern u16 fontpal;
char cusfont[] = {
	0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00,
	0x55, 0x55, 0x55, 0x55,
	0x44, 0x44, 0x44, 0x44,
	0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 
	
	0x00, 0x50, 0x04, 0x00,
	0x00, 0x50, 0x04, 0x00,
	0x00, 0x50, 0x04, 0x00,
	0x00, 0x50, 0x04, 0x00,
	0x00, 0x50, 0x04, 0x00,
	0x00, 0x50, 0x04, 0x00,
	0x00, 0x50, 0x04, 0x00,
	0x00, 0x50, 0x04, 0x00,

	0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x45,
	0x00, 0x00, 0x55, 0x44,
	0x00, 0x00, 0x45, 0x00,
	0x00, 0x50, 0x04, 0x00, 
	0x00, 0x50, 0x04, 0x00, 

	0x00, 0x50, 0x04, 0x00, 
	0x00, 0x50, 0x04, 0x00, 
	0x00, 0x00, 0x45, 0x00,
	0x00, 0x00, 0x55, 0x44,
	0x00, 0x00, 0x00, 0x45,
	0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00,

	0x00, 0x50, 0x04, 0x00, 
	0x00, 0x50, 0x04, 0x00, 
	0x00, 0x45, 0x00, 0x00,
	0x44, 0x55, 0x00, 0x00,
	0x45, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00,

	0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00,
	0x45, 0x00, 0x00, 0x00,
	0x44, 0x55, 0x00, 0x00,
	0x00, 0x45, 0x00, 0x00,
	0x00, 0x50, 0x04, 0x00, 
	0x00, 0x50, 0x04, 0x00, 

};

/* ------------------------------------------------------------------ *
 *  CJK tile splicing: 14x14 glyph -> 2x2 8x8 sub-tiles in 16x16 cell.
 *  Tiles are 4bpp (pixel 7 = pal7 grey-white). Custom tiles start at
 *  tile index 0x120 (font occupies 0x20..0x11F).
 * ------------------------------------------------------------------ */
#define CJK_TILE_BASE 0xB0
#define CJK_MAX_GLYPHS 160
static int cjk_slot[CJK_MAX_GLYPHS];
static int cjk_slot_map[3760];
static int cjk_slot_n;
/* v6 diagnostics: read-back of first write_cjk_tile call */
volatile unsigned int cjk_wrb0, cjk_wrb8;

/* reset tile slots (call before redrawing a menu) */
void cjk_prepare(void)
{
	int i;
	for (i = 0; i < CJK_MAX_GLYPHS; i++) cjk_slot[i] = -1;
	for (i = 0; i < 3760; i++) cjk_slot_map[i] = -1;
	cjk_slot_n = 0;
}

/* tile build buffer in main RAM: DMA source (CPU byte-writes to VRAM are
 * unreliable on real hardware; VRAM is a 16-bit bus) */
static u8 cjk_tb[128];
/* v7 diagnostics */
volatile unsigned int cjk_wrg;	/* glyph data OR (0 => glyph data is empty) */

/* write one 8x8 sub-tile (4bpp) for glyph g into custom tile slot.
 * Build the 32-byte tile in RAM, then DMA it into VRAM (same path as font). */
static void write_cjk_tile(int tileidx, const unsigned short *g, int sr, int sc)
{
	u8 *tmp = cjk_tb + (tileidx & 3) * 32;
	int r, c;
	for (r = 0; r < 32; r++) tmp[r] = 0;
	for (r = 0; r < 8; r++) {
		for (c = 0; c < 8; c++) {
			int gr = sr + r, gc = sc + c;
			int bit = 0;
			/* 14x14 glyph centred in 16x16 cell (offset 1,1) */
			if (gr >= 1 && gr <= 14 && gc >= 1 && gc <= 14) {
				if (g[gr - 1] & (0x2000 >> (gc - 1)))
					bit = 7;
			}
			if (bit)
				tmp[r * 4 + (c >> 1)] |= (u8)(bit << ((c & 1) * 4));
		}
	}
	if (tileidx == 0) {
		unsigned int go = 0;
		for (r = 0; r < 14; r++) go |= (unsigned int)g[r];
		cjk_wrg = go;
	}
	DC_FlushAll();	/* make CPU writes to cjk_tb visible to DMA */
	dmaCopyHalfWords(3, (u16 *)tmp, (u16 *)(SUB_CHR + (CJK_TILE_BASE + tileidx) * 32), 32);	/* 32 bytes = full 4bpp tile */
	DC_InvalidateAll();	/* VRAM written by DMA bypasses cache: invalidate so reads see real data */
	/* v7 diagnostics: read back (16-bit) after DMA */
	if (tileidx == 0) {
		const volatile u16 *rb = (const volatile u16 *)(SUB_CHR + CJK_TILE_BASE * 32);
		cjk_wrb0 = rb[0] & 0xFF;
		cjk_wrb8 = (rb[4] >> 8) & 0xFF;
	}
}

/* get (or create) the 4-tile slot for a glyph index */
static int get_cjk_slot(int idx)
{
	if (idx < 0 || idx >= cjk_count) return -1;
	if (cjk_slot_map[idx] >= 0) return cjk_slot_map[idx];
	if (cjk_slot_n >= CJK_MAX_GLYPHS) return -1;
	{
		int s = cjk_slot_n++;
		cjk_slot[s] = idx;
		cjk_slot_map[idx] = s;
		write_cjk_tile(s * 4 + 0, cjk_glyphs[idx], 0, 0);
		write_cjk_tile(s * 4 + 1, cjk_glyphs[idx], 0, 8);
		write_cjk_tile(s * 4 + 2, cjk_glyphs[idx], 8, 0);
		write_cjk_tile(s * 4 + 3, cjk_glyphs[idx], 8, 8);
		return s;
	}
}

/* decode next codepoint: UTF-8 preferred, GB2312/GBK fallback.
 * if is_gbk set, return value is a glyph index into cjk_glyphs[]. */
static unsigned int next_cp(const unsigned char **ps, int *is_gbk)
{
	const unsigned char *s = *ps;
	unsigned int b0 = s[0];
	if (b0 < 0x80) { *ps = s + 1; *is_gbk = 0; return b0; }
	/* UTF-8 3-byte (checked first: harmless for GBK since GB2312 second-level
	 * chars in qu 0xE0-0xEF are rare in file names) */
	if ((b0 & 0xF0) == 0xE0 && (s[1] & 0xC0) == 0x80 && (s[2] & 0xC0) == 0x80) {
		*ps = s + 3; *is_gbk = 0;
		return ((b0 & 0x0F) << 12) | ((s[1] & 0x3F) << 6) | (s[2] & 0x3F);
	}
	/* GB2312 quwei FIRST: GBK file names whose lead byte 0xC0-0xDF with
	 * trail 0xA1-0xBF would otherwise match the 2-byte UTF-8 pattern and
	 * decode to a non-Han codepoint (=> '?' in the menu). */
	if (b0 >= 0xB0 && b0 <= 0xF7 && s[1] >= 0xA1 && s[1] <= 0xFE) {
		int idx = (b0 - 0xB0) * 94 + (s[1] - 0xA1);
		if (idx >= 0 && idx < 3760 && gbk_map[idx] != 0xFFFF) {
			*ps = s + 2; *is_gbk = 1;
			return gbk_map[idx];
		}
	}
	/* UTF-8 2-byte */
	if ((b0 & 0xE0) == 0xC0 && (s[1] & 0xC0) == 0x80) {
		*ps = s + 2; *is_gbk = 0;
		return ((b0 & 0x1F) << 6) | (s[1] & 0x3F);
	}
	*ps = s + 1; *is_gbk = 0;
	return b0;
}

/* binary search cjk_unicodes; return glyph index or -1 */
static int cjk_find(unsigned int cp)
{
	int lo = 0, hi = cjk_count - 1;
	while (lo <= hi) {
		int mid = (lo + hi) >> 1;
		unsigned int u = cjk_unicodes[mid];
		if (u == cp) return mid;
		if (u < cp) lo = mid + 1; else hi = mid - 1;
	}
	return -1;
}

/* draw one codepoint in tile mode; returns columns advanced (1 or 2) */
/* debug exports (must be after cjk_find definition) */
int cjk_find_debug(unsigned int cp) { return cjk_find(cp); }
int cjk_count_debug(void) { return cjk_count; }
int cjk_slot_n_debug(void) { return cjk_slot_n; }

/* v14/v17 debug: '?'-source counters + raw bytes */
unsigned int cjk_db_bad[8]; unsigned char cjk_db_raw[8][6]; int cjk_db_nbad = 0;
int cjk_db_gbk[8];
int cjk_db_slot = 0;	/* get_cjk_slot failed */
int cjk_db_row  = 0;	/* row-full in menutext */
int cjk_db_lim  = 0;	/* q2 overflow in draw_cp_tile */
static int draw_cp_tile(u16 *p, unsigned int v, int is_gbk, int color, u16 *limit, const unsigned char *raw)
{
	u16 *q2;
	int s2;
	if (v < 0x80) {
		if (v >= 0x20) *p = (u16)(v | color);
		return 1;
	}
	if (v >= 0xA0 && v <= 0xA5) {           /* frame chars via cusfont */
		*p = (u16)((v - 0xA0 + 0xA0) | color);
		return 1;
	}
	if (is_gbk) s2 = get_cjk_slot((int)v);
	else s2 = get_cjk_slot(cjk_find(v));
	if (s2 < 0) {
		cjk_db_slot++;
		if (cjk_db_nbad < 8) {
			int ni = cjk_db_nbad, i;
			cjk_db_bad[ni] = v; cjk_db_gbk[ni] = is_gbk;
			for (i = 0; i < 6; i++) cjk_db_raw[ni][i] = raw[i];
			cjk_db_nbad = ni + 1;
		}
		*p = (u16)('?' | color); return 1;
	}
	q2 = p + 32;			/* next visible row: 32 entries per row */
	if (q2 + 1 >= limit) { cjk_db_lim++; *p = (u16)('?' | color); return 1; }
	p[0] = (u16)((CJK_TILE_BASE + s2 * 4 + 0) | color);
	p[1] = (u16)((CJK_TILE_BASE + s2 * 4 + 1) | color);
	q2[0] = (u16)((CJK_TILE_BASE + s2 * 4 + 2) | color);
	q2[1] = (u16)((CJK_TILE_BASE + s2 * 4 + 3) | color);
	return 2;
}

/*****************************
* name:			showconsole
* function:		show the console displayed on the screen below.
******************************/
void showconsole() {
	//clearconsole();
	if(__emuflags & ALLPIXEL) {
		videoSetModeSub(MODE_0_2D);
		videoBgDisableSub(3);
		dmaFillWords(0, BG_GFX_SUB , 192 * 256);		//clear the sub screen
		dmaCopyHalfWords(3,&font,(u16*)(SUB_CHR+0x400),4096);
		dmaCopyHalfWords(3,cusfont,(u16*)(SUB_CHR+0x1400),6*32);
		dmaCopyHalfWords(3,&fontpal,(u16*)BG_PALETTE_SUB,128);
	}
	__emuflags &= ~ALLPIXEL;

	powerOn(POWER_2D_B);
	powerOn(PM_BACKLIGHT_BOTTOM | PM_BACKLIGHT_TOP);
	lcdMainOnTop();
	screen_swap = 0;
	REG_DISPCNT_SUB=MODE_0_2D|DISPLAY_BG0_ACTIVE|DISPLAY_BG1_ACTIVE|DISPLAY_WIN0_ON;
	REG_BG0CNT_SUB=BG_TILE_BASE(1)|BG_64x32;
	REG_BG1CNT_SUB=BG_TILE_BASE(1)|BG_64x32;
	REG_BG0HOFS_SUB=0;
	REG_BG0VOFS_SUB=0;
	REG_BG1HOFS_SUB=0;
	REG_BG1VOFS_SUB=0;

	REG_BG3Y_SUB = 0;

	SUB_WIN0_X0=0;
	SUB_WIN0_X1=255;
	SUB_WIN0_Y0=24;
	SUB_WIN0_Y1=191;
	SUB_WIN_IN=1;
	SUB_WIN_OUT=2;

	swiWaitForVBlank();
}

/*****************************
* name:			hideconsole
******************************/
void hideconsole() {
	swiWaitForVBlank();
	//powerOff(POWER_2D_B);
	if((!(__emuflags & ALLPIXELON))) {
		__emuflags &= ~ALLPIXEL;
		if(!(__emuflags & SCREENSWAP)) {
			powerOff(PM_BACKLIGHT_BOTTOM);			// This cannot be accessed directly.
			powerOn(PM_BACKLIGHT_TOP);
			lcdMainOnTop();
		} else {
			powerOn(PM_BACKLIGHT_BOTTOM);
			powerOff(PM_BACKLIGHT_TOP);
			lcdMainOnBottom();
		}
	} else {
		int pos = ad_ypos / (1 << 16);

		__emuflags |= ALLPIXEL;
		dmaFillWords(0, BG_GFX_SUB , 192 * 256);		// clear the sub screen
		dmaCopy(BG_PALETTE, BG_PALETTE_SUB, 0x400);		// copy the palette
		powerOn(PM_BACKLIGHT_BOTTOM);
		powerOn(PM_BACKLIGHT_TOP);

		if (pos < -(240 - 192)/2) {
			__emuflags |= SCREENSWAP;
			all_pix_start = 0;
			all_pix_end = 1 - pos;
			lcdMainOnBottom();
		} else {
			__emuflags &= ~SCREENSWAP;
			all_pix_start = 192 - pos;
			if(all_pix_start > 239)
				all_pix_start = 239;
			all_pix_end = 240;
			lcdMainOnTop();
		}
		videoSetModeSub(MODE_5_2D);
		videoBgEnableSub(3);
		BGCTRL_SUB[3] = (typeof(BGCTRL_SUB[3]))(BgSize_B8_256x256 | BG_MAP_BASE(0) | BG_TILE_BASE(0));
		swiWaitForVBlank();
		videoSetModeSub(MODE_5_2D);
		videoBgEnableSub(3);
		BGCTRL_SUB[3] = (typeof(BGCTRL_SUB[3]))(BgSize_B8_256x256  | BG_MAP_BASE(0) | BG_TILE_BASE(0));
		rescale(ad_scale, ad_ypos);
	}
}

/*****************************
* name:			clearconsole
******************************/
void clearconsole() {
	memset((void *)(SUB_BG),0,32*32*2);	/* wipe whole 32x32 map (2048 bytes) */
	REG_BG0VOFS=0;
}

/*****************************
* name:			consoleinit
******************************/
void consoleinit() {
	cjk_prepare();
	dmaCopyHalfWords(3,&font,(u16*)(SUB_CHR+0x400),4096);
	dmaCopyHalfWords(3,cusfont,(u16*)(SUB_CHR+0x1400),6*32);
	dmaCopyHalfWords(3,&fontpal,(u16*)BG_PALETTE_SUB,128);
	showconsole();
}

/*****************************
* name:			menutext
* function:		to show one line in a menu, selected or not, file or dir.
******************************/
void menutext(int line,char *s,int selected) {
	int color=selected?0x1000:0;	/* palette 1 highlight (NDS 4bpp: palette=bit12+, H-flip=bit10=0x400!) */
	u16 *base=(u16*)(SUB_BG+line*64);	/* 32 entries per row (real BG row) */
	u16 *p=base;
	u16 *limit=(u16*)(SUB_BG+32*32*2);	/* map end: 32x32 = 1024 entries = 2048 bytes */
	u16 c = 0;

	if(!selected) c=' ';
	else if(selected==1) c='*';	//normal selected look
	else if(selected==2) c='<';
	*p++=c;

	while(*s && (p-base)<32) {
		const unsigned char *pp=(const unsigned char *)s;
		const unsigned char *raw=(const unsigned char *)s;
		int is_gbk; unsigned int v;
		v=next_cp(&pp,&is_gbk);
		s=(char *)pp;
		if (v < 0x80) {
			if (v >= 0x20 && (p-base)<32) *p++=(u16)(v|color);
			continue;
		}
		if ((p-base)>=30) { cjk_db_row++; *p++=(u16)('?'|color); continue; }
		p += draw_cp_tile(p, v, is_gbk, color, limit, raw);
	}
	if(selected==2)
		*p++ = '>'|color;
	while((p-base)<32)
		*p++=' ';
}

/*****************************
* name:			consoletext
******************************/
void consoletext(int offset,char *s,int color) {
	u16 *base=(u16*)(SUB_BG+offset);
	u16 *p=base;
	u16 *limit=(u16*)(SUB_BG+64*64);
	while (*s) {
		if (*s == '\n') {
			p = (u16 *)(((int)p + 62) & (~63));
			s++;
		} else if (*s == '\t') {
			p = (u16 *)(((int)p + 14)&(~15));
			s++;
		} else if (*s == '\r') {
			p = (u16 *)((((int)p)&~63) + (offset & 63) + 64);
			s++;
		}
		if(!*s)
			break;
		{
			const unsigned char *pp=(const unsigned char *)s;
			int is_gbk; unsigned int v;
			v=next_cp(&pp,&is_gbk);
			s=(char *)pp;
			if (v < 0x80) {
				if (v >= 0x20) *p++=(u16)(v|color);
			} else {
				p += draw_cp_tile(p, v, is_gbk, color, limit, (const unsigned char *)s);
			}
		}
	}
}

/*****************************
* name:			hex
******************************/
void hex(int offset,int d,int n) {
	u16 *p=(u16*)(SUB_BG+offset);
	while(n>=0) {
		int c=d&0x0f;
		if(c<10)c+='0'; else c=c-10+'A';
		d>>=4;
		*p++=(u16)(c|0);
		n--;
	}
}
